#ifndef _INTEL_MEMMAN_H_
#define _INTEL_MEMMAN_H_

Bool intel_memman_init(struct intel_driver_data *intel);
Bool intel_memman_terminate(struct intel_driver_data *intel);

#endif /* _INTEL_MEMMAN_H_ */
