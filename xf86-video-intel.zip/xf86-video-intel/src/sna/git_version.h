static const char git_version[] = "2.99.917-863-g6afed33b";
